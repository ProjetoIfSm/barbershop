<!doctype html>
<html lang="en">
<head>

<meta charset="utf-8">

<meta name="author" content="Julio Leal">
<title>Barber Shop</title>
      <!--Import materialize.css-->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

     <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

      <!--Let browser know website is optimized for mobile-->

      </head>
      <body class="blue-grey darken-1">
      <footer class="card-panel blue-grey darken-3">
      <h1 class="white-text">Barber Shop</h1>
      </footer>
      <hr />