      <!--JavaScript at end of body for optimized loading-->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

      <script>
        M.AutoInit();
      </script>
      <hr />
   
  




      <footer class="card-panel blue-grey darken-3">
          <div class="container">
            <div class="row">
              <div class="col 12 s19">
                <h5 class="white-text">BarberShop</h5>
                <p class="grey-text text-lighten-4">A barbearia da cidade desde 1820!</p>
              </div>
            </div>
          </div>
          <div class="white-text">
            <div class="container">
            © 2021 Copyright
            </div>
          </div>
        </footer>



      </body>
      </html>